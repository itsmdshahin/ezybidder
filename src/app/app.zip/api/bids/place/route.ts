import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabaseServerClient';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { auction_id, amount } = body;

    const { data: auth, error: authErr } = await supabase.auth.getUser();
    if (authErr || !auth.user)
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

    const userId = auth.user.id;

    // Insert bid
    const { data: bid, error: bidErr } = await supabase
      .from('bids')
      .insert({
        auction_id,
        bidder_id: userId,
        amount,
        is_proxy_bid: false,
        is_winning: true,
      })
      .select()
      .single();

    if (bidErr)
      return NextResponse.json({ error: bidErr.message }, { status: 400 });

    // Update auction (optimistic)
    await supabase
      .from('auctions')
      .update({
        current_bid: amount,
        winner_id: userId,
        total_bids: supabase.rpc('increment', { x: 1 }),
      })
      .eq('id', auction_id);

    return NextResponse.json({ ok: true, bid });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
