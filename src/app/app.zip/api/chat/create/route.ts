import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServerClient";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { buyer_id, seller_id, vehicle_id, auction_id } = body;

  const { data, error } = await supabase
    .from("conversations")
    .insert({
      buyer_id,
      seller_id,
      vehicle_id,
      auction_id,
    })
    .select("*")
    .single();

  if (error)
    return NextResponse.json({ error }, { status: 400 });

  return NextResponse.json(data);
}
