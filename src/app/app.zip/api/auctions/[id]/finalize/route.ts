// src/app/api/auctions/[id]/finalize/route.ts
import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServerClient";

export async function POST(
  req: NextRequest,
  context: { params: { id: string } }
) {
  const auctionId = context.params.id;

  try {
    // Load auction
    const { data: auction, error: auctionErr } = await supabase
      .from("auctions")
      .select("*")
      .eq("id", auctionId)
      .single();

    if (auctionErr || !auction) {
      return NextResponse.json(
        { error: "Auction not found" },
        { status: 404 }
      );
    }

    const sellerId = auction.seller_id;
    const winnerId = auction.winner_id;
    const vehicleId = auction.vehicle_id;

    // End if no winner
    if (!winnerId) {
      await supabase.from("auctions").update({
        status: "ended",
      }).eq("id", auctionId);

      return NextResponse.json({
        status: "ended",
        message: "Auction ended with no bids.",
      });
    }

    // END AUCTION
    await supabase
      .from("auctions")
      .update({
        status: "ended",
      })
      .eq("id", auctionId);

    // Check if conversation already exists
    const { data: existingConv } = await supabase
      .from("conversations")
      .select("id")
      .eq("auction_id", auctionId)
      .eq("buyer_id", winnerId)
      .eq("seller_id", sellerId)
      .maybeSingle();

    let conversationId = existingConv?.id;

    // Create if not exists
    if (!conversationId) {
      const { data: newConv, error: convErr } = await supabase
        .from("conversations")
        .insert({
          auction_id: auctionId,
          buyer_id: winnerId,
          seller_id: sellerId,
          vehicle_id: vehicleId,
        })
        .select()
        .single();

      if (convErr) {
        console.error("Conversation create error:", convErr);
        return NextResponse.json(
          { error: "Failed to create chat" },
          { status: 500 }
        );
      }

      conversationId = newConv.id;

      // Add first system message
      await supabase.from("messages").insert({
        conversation_id: conversationId,
        sender_id: sellerId,
        recipient_id: winnerId,
        content: "Congratulations! You won the auction. Let's arrange payment and collection.",
        message_type: "system",
        auction_id: auctionId,
        vehicle_id: vehicleId
      });
    }

    // Send notification to buyer
    await supabase.from("notifications").insert({
      user_id: winnerId,
      title: "You won an auction!",
      message: "Open the chat to coordinate with the seller.",
      type: "auction",
      priority: "high",
      action_url: `/chat/${conversationId}`,
    });

    // Send notification to seller
    await supabase.from("notifications").insert({
      user_id: sellerId,
      title: "Your auction has a winner",
      message: "A buyer is ready to contact you.",
      type: "auction",
      priority: "high",
      action_url: `/chat/${conversationId}`,
    });

    return NextResponse.json({
      status: "ended",
      winnerId,
      sellerId,
      conversationId,
    });
  } catch (err) {
    console.error("Finalize auction error:", err);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
