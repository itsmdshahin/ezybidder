'use client';

import { useEffect, useState } from "react";
import Link from "next/link";

export default function ChatInbox() {
  const [conversations, setConversations] = useState([]);

  useEffect(() => {
    fetch("/api/chat")
      .then((res) => res.json())
      .then(setConversations);
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Messages</h1>

      {conversations.length === 0 && (
        <p className="text-muted-foreground">No conversations yet.</p>
      )}

      {conversations.map((c) => {
        const last = c.messages?.[c.messages.length - 1];
        const vehicle = c.vehicles;

        return (
          <Link
            href={`/chat/${c.id}`}
            key={c.id}
            className="block p-4 border rounded-lg hover:bg-muted transition-all"
          >
            <div className="font-semibold">
              {vehicle?.make} {vehicle?.model} {vehicle?.year}
            </div>

            <div className="text-xs text-muted-foreground">
              {last?.content || "No messages yet"}
            </div>
          </Link>
        );
      })}
    </div>
  );
}
