// src/app/chat/components/ChatInbox.tsx
'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface Conversation {
  id: string;
  buyer_id: string;
  seller_id: string;
  vehicle_id: string | null;
  auction_id: string | null;
  created_at: string;
}

const ChatInbox = () => {
  const router = useRouter();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const { data, error } = await supabase.auth.getUser();
      if (error || !data.user) {
        setLoading(false);
        return;
      }
      setCurrentUserId(data.user.id);

      const { data: convs, error: convErr } = await supabase
        .from('conversations')
        .select('*')
        .or(`buyer_id.eq.${data.user.id},seller_id.eq.${data.user.id}`)
        .order('created_at', { ascending: false });

      if (!convErr && convs) {
        setConversations(convs);
      }
      setLoading(false);
    };

    load();
  }, []);

  if (loading) {
    return <div className="text-muted-foreground text-sm">Loading conversations...</div>;
  }

  if (!currentUserId) {
    return <div className="text-muted-foreground text-sm">Please sign in to view messages.</div>;
  }

  if (!conversations.length) {
    return (
      <div className="border border-border rounded-lg p-6 bg-card text-center text-sm text-muted-foreground">
        No conversations yet. Win or sell an auction to start chatting.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {conversations.map((c) => {
        const isBuyer = c.buyer_id === currentUserId;
        const label = isBuyer ? 'Seller' : 'Buyer';

        return (
          <button
            key={c.id}
            onClick={() => router.push(`/chat/${c.id}`)}
            className="w-full flex items-center justify-between px-4 py-3 rounded-lg border border-border bg-card hover:bg-muted/50 transition-colors text-left"
          >
            <div>
              <div className="flex items-center gap-2">
                <Icon name="ChatBubbleLeftRightIcon" size={18} />
                <p className="text-sm font-medium text-card-foreground">
                  Conversation with {label}
                </p>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Auction: {c.auction_id ?? 'N/A'} • Vehicle: {c.vehicle_id ?? 'N/A'}
              </p>
            </div>
            <Icon name="ChevronRightIcon" size={18} className="text-muted-foreground" />
          </button>
        );
      })}
    </div>
  );
};

export default ChatInbox;
