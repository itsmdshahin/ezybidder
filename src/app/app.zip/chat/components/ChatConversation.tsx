// src/app/chat/components/ChatConversation.tsx
'use client';

import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import Icon from '@/components/ui/AppIcon';

interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  message_type: string;
  created_at: string;
}

interface ChatConversationProps {
  conversationId: string;
}

const ChatConversation = ({ conversationId }: ChatConversationProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const { data, error } = await supabase.auth.getUser();
      if (!error && data.user) {
        setCurrentUserId(data.user.id);
      }

      const { data: msgs, error: msgErr } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (!msgErr && msgs) {
        setMessages(msgs);
      }

      setLoading(false);
    };

    load();

    // simple polling (replace with Supabase realtime later if you want)
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [conversationId]);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !currentUserId) return;

    const { data: conv, error: convErr } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .single();

    if (convErr || !conv) return;

    const recipientId =
      currentUserId === conv.buyer_id ? conv.seller_id : conv.buyer_id;

    const { data: inserted, error: insertErr } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        sender_id: currentUserId,
        recipient_id: recipientId,
        vehicle_id: conv.vehicle_id,
        auction_id: conv.auction_id,
        content: input.trim(),
        message_type: 'text',
      })
      .select()
      .single();

    if (insertErr) {
      console.error('message insert error', insertErr);
      return;
    }

    setMessages((prev) => [...prev, inserted as Message]);
    setInput('');
  };

  if (loading) {
    return <div className="text-sm text-muted-foreground">Loading conversation...</div>;
  }

  if (!currentUserId) {
    return <div className="text-sm text-muted-foreground">Please sign in to view messages.</div>;
  }

  return (
    <div className="border border-border rounded-lg bg-card flex flex-col h-[70vh]">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Icon name="ChatBubbleLeftRightIcon" size={18} />
        <h2 className="text-sm font-semibold text-card-foreground">Conversation</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {messages.length === 0 && (
          <p className="text-xs text-muted-foreground text-center mt-4">
            No messages yet. Say hello!
          </p>
        )}
        {messages.map((m) => {
          const isMe = m.sender_id === currentUserId;
          return (
            <div
              key={m.id}
              className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs rounded-xl px-3 py-2 text-xs ${
                  isMe
                    ? 'bg-primary text-primary-foreground'
                    : m.message_type === 'system'
                    ? 'bg-muted text-muted-foreground'
                    : 'bg-muted/70 text-card-foreground'
                }`}
              >
                <p className="whitespace-pre-wrap break-words">{m.content}</p>
                <p className="mt-1 text-[10px] opacity-70 text-right">
                  {new Date(m.created_at).toLocaleTimeString('en-GB', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="border-t border-border p-3 flex items-center gap-2">
        <input
          className="flex-1 text-sm px-3 py-2 rounded-md border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
          placeholder="Type your message…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
        />
        <button
          onClick={handleSend}
          className="inline-flex items-center justify-center rounded-md px-3 py-2 bg-primary text-primary-foreground text-sm hover:bg-primary/90"
        >
          <Icon name="PaperAirplaneIcon" size={16} className="-rotate-45 mr-1" />
          Send
        </button>
      </div>
    </div>
  );
};

export default ChatConversation;
