'use client';

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function ChatWindow({ params }) {
  const conversationId = params.id;
  const [messages, setMessages] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [text, setText] = useState("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) setCurrentUser(data.user.id);
    });
  }, []);

  useEffect(() => {
    fetch(`/api/chat/${conversationId}`)
      .then((res) => res.json())
      .then(setMessages);

    // Realtime subscription
    const channel = supabase
      .channel(`chat:${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          setMessages((prev) => [...prev, payload.new]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversationId]);

  const sendMessage = async () => {
    if (!text.trim()) return;

    const recipientId = messages[0]?.sender_id === currentUser
      ? messages[0]?.recipient_id
      : messages[0]?.sender_id;

    await fetch(`/api/chat/${conversationId}`, {
      method: "POST",
      body: JSON.stringify({
        senderId: currentUser,
        recipientId,
        content: text,
      }),
    });

    setText("");
  };

  return (
    <div className="max-w-3xl mx-auto p-6 flex flex-col h-[85vh]">
      {/* message area */}
      <div className="flex-1 overflow-y-auto border rounded-lg p-4 space-y-4 bg-muted">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`p-3 rounded-lg max-w-xs ${
              m.sender_id === currentUser
                ? "bg-primary text-white ml-auto"
                : "bg-white border mr-auto"
            }`}
          >
            {m.content}
          </div>
        ))}
      </div>

      {/* input */}
      <div className="mt-4 flex gap-3">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="flex-1 border rounded-md p-2"
          placeholder="Write a message..."
        />
        <button
          onClick={sendMessage}
          className="px-4 py-2 bg-primary text-white rounded-md"
        >
          Send
        </button>
      </div>
    </div>
  );
}
